// TophHub Background Service Worker - Handles GitHub REST API Operations

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'COMMIT_SOLUTION') {
    handleCommit(request.payload)
      .then(result => sendResponse(result))
      .catch(error => {
        console.error('[TophHub Background] Error:', error);
        sendResponse({ success: false, error: error.message || 'Unknown error occurred' });
      });
    return true; // Keep message channel open for async response
  }

  if (request.action === 'FETCH_TOPH_PROBLEM') {
    fetchTophProblem(request.slug)
      .then(data => sendResponse({ success: true, data }))
      .catch(err => {
        console.warn('[TophHub Background] Problem fetch error:', err);
        sendResponse({ success: false, error: err.message });
      });
    return true;
  }
});

async function handleCommit(data) {
  const {
    problemSlug,
    problemTitle,
    language,
    cpuTime,
    memory,
    code,
    problemDescription,
    problemUrl,
    submissionId
  } = data;

  if (!code || !code.trim()) {
    throw new Error('No source code found to commit.');
  }

  // Retrieve configuration
  const config = await getStorage(['githubToken', 'repo', 'branch', 'langPreference', 'syncedCount', 'userInfo']);
  const token = (config.githubToken || '').trim();
  let rawRepo = (config.repo || '').trim();
  const branch = (config.branch || 'main').trim();

  if (!token || !rawRepo) {
    throw new Error('GitHub token or repository not configured in TophHub settings.');
  }

  // Sanitize repo string: handles "owner/repo", "https://github.com/owner/repo", or "repo" with userInfo
  rawRepo = rawRepo.replace(/^https?:\/\/github\.com\//i, '').replace(/^\/+|\/+$/g, '');
  let parts = rawRepo.split('/').filter(Boolean);
  let owner = '', repoName = '';
  if (parts.length >= 2) {
    owner = parts[0];
    repoName = parts[1];
  } else if (parts.length === 1 && config.userInfo && config.userInfo.login) {
    owner = config.userInfo.login;
    repoName = parts[0];
  }

  if (!owner || !repoName) {
    throw new Error(`Repository "${config.repo}" is invalid. Please set as "username/repository" in TophHub settings.`);
  }

  // Determine file extension (defaults to .cpp)
  const ext = getFileExtension(language, config.langPreference);
  const cleanSlug = (problemSlug || 'problem').trim().toLowerCase();
  const solutionPath = `toph/${cleanSlug}/solution.${ext}`;
  const problemReadmePath = `toph/${cleanSlug}/README.md`;
  const rootReadmePath = `README.md`;

  // 1. Prepare Solution Content (Clean code without comment bloat)
  const solutionContent = code.trim() + '\n';

  // 2. Commit Solution File
  const commitMsg = `Solve: ${problemTitle || cleanSlug} [Accepted] (${language || 'C++'})`;
  await putGitHubFile(owner, repoName, solutionPath, commitMsg, solutionContent, branch, token);

  // 3. Commit Problem README
  const problemReadmeContent =
`# [${problemTitle || cleanSlug}](${problemUrl || `https://toph.co/p/${cleanSlug}`})

- **Platform:** [Toph.co](https://toph.co)
- **Problem Slug:** \`${cleanSlug}\`
- **Verdict:** Accepted (AC)
- **Language:** ${language || 'C++'}
- **CPU Time:** \`${cpuTime || '-'}\`
- **Memory:** \`${memory || '-'}\`
- **Submission ID:** \`${submissionId || '-'}\`
- **Solution:** [\`solution.${ext}\`](./solution.${ext})

---

## Problem Description

${problemDescription || '_Problem statement not available. View directly on [Toph.co](' + (problemUrl || `https://toph.co/p/${cleanSlug}`) + ')._'}
`;

  try {
    await putGitHubFile(owner, repoName, problemReadmePath, `Docs: Add problem statement for ${problemTitle || cleanSlug}`, problemReadmeContent, branch, token);
  } catch (e) {
    console.warn('[TophHub] Failed to update problem README (non-critical):', e);
  }

  // 4. Update Root README (Index Table of Solved Problems)
  try {
    await updateRootReadme(owner, repoName, rootReadmePath, {
      title: problemTitle || cleanSlug,
      slug: cleanSlug,
      url: problemUrl || `https://toph.co/p/${cleanSlug}`,
      language: language || 'C++',
      cpuTime: cpuTime || '-',
      memory: memory || '-',
      ext
    }, branch, token);
  } catch (e) {
    console.warn('[TophHub] Failed to update root README index:', e);
  }

  // Increment synced count
  const newCount = (config.syncedCount || 0) + 1;
  await chrome.storage.local.set({ 
    syncedCount: newCount,
    lastSyncedProblem: problemTitle || cleanSlug
  });

  return {
    success: true,
    fileUrl: `https://github.com/${owner}/${repoName}/blob/${branch}/${solutionPath}`
  };
}

// GitHub API Helper: Fetch existing file SHA
async function getFileSha(owner, repo, path, branch, token) {
  try {
    const url = `https://api.github.com/repos/${owner}/${repo}/contents/${path}?ref=${branch}`;
    const authHeader = (token.startsWith('Bearer ') || token.startsWith('token ')) ? token : `Bearer ${token}`;
    const res = await fetch(url, {
      headers: {
        'Authorization': authHeader,
        'Accept': 'application/vnd.github.v3+json',
        'User-Agent': 'TophHub-Extension/1.0.0'
      }
    });

    if (res.status === 200) {
      const data = await res.json();
      return { sha: data.sha, content: decodeBase64(data.content) };
    }
    return { sha: null, content: null };
  } catch (err) {
    return { sha: null, content: null };
  }
}

// GitHub API Helper: Create or Update File
async function putGitHubFile(owner, repo, path, message, contentStr, branch, token) {
  const existing = await getFileSha(owner, repo, path, branch, token);
  const encodedContent = encodeBase64(contentStr);

  const authHeader = (token.startsWith('Bearer ') || token.startsWith('token ')) ? token : `Bearer ${token}`;
  const commonHeaders = {
    'Authorization': authHeader,
    'Accept': 'application/vnd.github.v3+json',
    'Content-Type': 'application/json',
    'User-Agent': 'TophHub-Extension/1.0.0'
  };

  const payload = {
    message: message,
    content: encodedContent
  };

  if (branch) {
    payload.branch = branch;
  }

  if (existing.sha) {
    payload.sha = existing.sha;
  }

  const url = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;
  let res = await fetch(url, {
    method: 'PUT',
    headers: commonHeaders,
    body: JSON.stringify(payload)
  });

  // If branch doesn't exist on a new repository, retry without branch parameter
  if (!res.ok && (res.status === 404 || res.status === 409 || res.status === 422) && payload.branch) {
    console.warn(`[TophHub] PUT ${path} failed with status ${res.status}. Retrying without branch...`);
    delete payload.branch;
    res = await fetch(url, {
      method: 'PUT',
      headers: commonHeaders,
      body: JSON.stringify(payload)
    });
  }

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.message || `GitHub API error (${res.status} ${res.statusText})`);
  }

  return await res.json();
}

// Automatically maintains a structured table of solved problems in the root README
async function updateRootReadme(owner, repo, rootPath, problemData, branch, token) {
  const existing = await getFileSha(owner, repo, rootPath, branch, token);
  let content = existing.content;

  const tableHeader = '| # | Problem | Language | Time | Memory | Solution |\n|---|---|---|---|---|---|';
  const newRow = `| - | [${problemData.title}](${problemData.url}) | \`${problemData.language}\` | \`${problemData.cpuTime}\` | \`${problemData.memory}\` | [solution.${problemData.ext}](./toph/${problemData.slug}/solution.${problemData.ext}) |`;

  if (!content) {
    // Initial README template
    content = 
`# Toph.co Solutions (C++)

A collection of competitive programming solutions solved on [Toph.co](https://toph.co), automatically synced using [TophHub](https://github.com/${owner}/${repo}).

## 📊 Solved Problems

${tableHeader}
${newRow}

---
*Created automatically by TophHub Extension.*
`;
  } else {
    // Check if problem is already in the table
    if (content.includes(`toph/${problemData.slug}/`)) {
      // Already present in README, no update needed
      return;
    }

    if (content.includes(tableHeader)) {
      // Append row to existing table
      content = content.replace(tableHeader, `${tableHeader}\n${newRow}`);
    } else {
      // Table doesn't exist, append section
      content += `\n\n## 📊 Solved Problems\n\n${tableHeader}\n${newRow}\n`;
    }
  }

  await putGitHubFile(owner, repo, rootPath, `Docs: Update solved index for ${problemData.title}`, content, branch, token);
}

// Extension resolution
function getFileExtension(lang, pref) {
  if (pref === 'cpp') return 'cpp';
  const l = (lang || '').toLowerCase();
  if (l.includes('c++') || l.includes('cpp')) return 'cpp';
  if (l.includes('python')) return 'py';
  if (l.includes('java')) return 'java';
  if (l.includes('c#') || l.includes('csharp')) return 'cs';
  if (l.includes('rust')) return 'rs';
  if (l.includes('go')) return 'go';
  if (l.includes('kotlin')) return 'kt';
  if (l.includes('c')) return 'c';
  return 'cpp'; // default to C++
}

// UTF-8 safe base64 encoding/decoding
function encodeBase64(str) {
  return btoa(unescape(encodeURIComponent(str)));
}

function decodeBase64(str) {
  try {
    return decodeURIComponent(escape(atob(str.replace(/\s/g, ''))));
  } catch (e) {
    return atob(str.replace(/\s/g, ''));
  }
}

function getStorage(keys) {
  return new Promise(resolve => {
    chrome.storage.local.get(keys, resolve);
  });
}

// Fetch Problem Data directly from Toph.co (runs in background with host permissions, bypassing CORS)
async function fetchTophProblem(slug) {
  const cleanSlug = (slug || '')
    .replace(/.*toph\.co\/p\//i, '')
    .replace(/[\/?#].*$/, '')
    .trim()
    .toLowerCase();

  if (!cleanSlug) {
    throw new Error('Invalid problem slug');
  }

  // 1. Try toph.co JSON endpoint
  try {
    const jsonRes = await fetch(`https://toph.co/p/${cleanSlug}.json`, {
      headers: {
        'Accept': 'application/json, text/plain, */*',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
      }
    });

    if (jsonRes.ok) {
      const json = await jsonRes.json();
      const statement = (json.statement && json.statement.en_us) 
        ? json.statement.en_us 
        : (json.statement ? Object.values(json.statement)[0] : {});
      const rawSamples = json.samples || [];
      const samples = rawSamples.map(s => ({
        stdin: (s.input || '').replace(/\r\n/g, '\n').trim(),
        expected: (s.output || '').replace(/\r\n/g, '\n').trim()
      })).filter(s => s.stdin || s.expected);

      const title = (statement && statement.title)
        ? statement.title.trim()
        : cleanSlug.split('-').map(s => s.charAt(0).toUpperCase() + s.slice(1)).join(' ');

      return {
        slug: cleanSlug,
        title: title,
        desc: stripHtml(statement ? statement.bodyHTML || '' : ''),
        input: stripHtml(statement ? statement.inputHTML || '' : ''),
        output: stripHtml(statement ? statement.outputHTML || '' : ''),
        samples: samples.length > 0 ? samples : [{ stdin: '', expected: '' }]
      };
    }
  } catch (err) {
    console.warn('[TophHub Background] JSON fetch error:', err);
  }

  // 2. Fallback to scraping the HTML problem page
  try {
    const htmlRes = await fetch(`https://toph.co/p/${cleanSlug}`);
    if (htmlRes.ok) {
      const html = await htmlRes.text();
      let title = '';
      const titleMatch = html.match(/<title>([^<]*)<\/title>/i);
      if (titleMatch) {
        title = titleMatch[1].split('|')[0].trim();
      }
      const h1Match = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
      if (h1Match && stripHtml(h1Match[1])) {
        title = stripHtml(h1Match[1]);
      }

      return {
        slug: cleanSlug,
        title: title || cleanSlug.split('-').map(s => s.charAt(0).toUpperCase() + s.slice(1)).join(' '),
        desc: `Problem statement for ${title || cleanSlug}. Visit https://toph.co/p/${cleanSlug} for details.`,
        input: 'Standard input format.',
        output: 'Standard output format.',
        samples: [{ stdin: '', expected: '' }]
      };
    }
  } catch (err) {
    console.warn('[TophHub Background] HTML fetch error:', err);
  }

  throw new Error(`Could not fetch problem "${cleanSlug}" from Toph.co`);
}

function stripHtml(html) {
  if (!html) return '';
  return html
    .replace(/<[^>]+>/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

